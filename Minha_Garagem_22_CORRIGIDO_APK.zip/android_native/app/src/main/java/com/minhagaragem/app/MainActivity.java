package com.minhagaragem.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.util.Calendar;

public class MainActivity extends Activity {
    private WebView webView;
    private AlarmManager alarmManager;
    private static final int REQ_NOTIF = 501;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        alarmManager = (AlarmManager)getSystemService(ALARM_SERVICE);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true);
        webView.setWebViewClient(new WebViewClient()); webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AlarmBridge(this), "AndroidAlarm");
        webView.loadUrl("file:///android_asset/index.html");
        requestNotificationPermission();
    }

    private void requestNotificationPermission(){
        if(Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
    }

    public void openExactAlarmSettings(){
        if(Build.VERSION.SDK_INT >= 31 && !alarmManager.canScheduleExactAlarms()){
            try { startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:"+getPackageName()))); }
            catch(Exception e){
                Intent intent = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
                intent.setData(Uri.parse("package:" + getPackageName()));
                startActivity(intent);
            }
        }
    }

    public class AlarmBridge {
        private final Context ctx; AlarmBridge(Context c){ctx=c;}
        @JavascriptInterface public void scheduleAlarm(String id,String date,String time,String message){
            try{
                if(Build.VERSION.SDK_INT >= 31 && !alarmManager.canScheduleExactAlarms()){
                    runOnUiThread(() -> { Toast.makeText(MainActivity.this,"Ative 'Alarmes e lembretes' para o alarme funcionar com o app fechado.",Toast.LENGTH_LONG).show(); openExactAlarmSettings(); });
                    return;
                }
                long when=parseDateTime(date,time); if(when <= System.currentTimeMillis()) return;
                AlarmStore.put(ctx,id,date,time,message);
                Intent i=new Intent(ctx,AlarmReceiver.class).setAction(AlarmReceiver.ACTION_ALARM);
                i.putExtra("id",id); i.putExtra("message",message);
                PendingIntent pi=PendingIntent.getBroadcast(ctx,stableCode(id),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
                AlarmManager.AlarmClockInfo info=new AlarmManager.AlarmClockInfo(when, PendingIntent.getActivity(ctx,0,new Intent(ctx,MainActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE));
                alarmManager.setAlarmClock(info,pi);
            }catch(Exception e){ e.printStackTrace(); }
        }
        @JavascriptInterface public void cancelAlarm(String id){
            try{
                Intent i=new Intent(ctx,AlarmReceiver.class).setAction(AlarmReceiver.ACTION_ALARM);
                PendingIntent pi=PendingIntent.getBroadcast(ctx,stableCode(id),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
                alarmManager.cancel(pi); AlarmStore.remove(ctx,id);
            }catch(Exception e){e.printStackTrace();}
        }
        @JavascriptInterface public void openAlarmPermission(){ runOnUiThread(MainActivity.this::openExactAlarmSettings); }
        @JavascriptInterface public void downloadApp(){
            new Thread(() -> {
                try {
                    String name = "Minha_Garagem.html";
                    if (Build.VERSION.SDK_INT >= 29) {
                        android.content.ContentValues values = new android.content.ContentValues();
                        values.put(android.provider.MediaStore.Downloads.DISPLAY_NAME, name);
                        values.put(android.provider.MediaStore.Downloads.MIME_TYPE, "text/html");
                        values.put(android.provider.MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                        Uri uri = getContentResolver().insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                        if(uri == null) throw new Exception("Não foi possível criar o arquivo");
                        try (InputStream in = getAssets().open("index.html"); java.io.OutputStream out = getContentResolver().openOutputStream(uri)) {
                            byte[] buf = new byte[8192]; int n; while((n=in.read(buf))!=-1) out.write(buf,0,n);
                        }
                    } else {
                        File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                        if(!dir.exists()) dir.mkdirs();
                        File file = new File(dir,name);
                        try(InputStream in=getAssets().open("index.html"); FileOutputStream out=new FileOutputStream(file)){ byte[] buf=new byte[8192]; int n; while((n=in.read(buf))!=-1) out.write(buf,0,n); }
                    }
                    runOnUiThread(() -> Toast.makeText(MainActivity.this,"Cópia salva em Downloads/Minha_Garagem.html",Toast.LENGTH_LONG).show());
                } catch(Exception e){ e.printStackTrace(); runOnUiThread(() -> Toast.makeText(MainActivity.this,"Não foi possível salvar a cópia.",Toast.LENGTH_LONG).show()); }
            }).start();
        }
        private int stableCode(String id){ try{return (int)(Long.parseLong(id)%1000000000L);}catch(Exception e){return id.hashCode();} }
        private long parseDateTime(String d,String t){
            String[] ds=d.split("-"); String[] ts=t.split(":"); Calendar c=Calendar.getInstance(); c.set(Calendar.YEAR,Integer.parseInt(ds[0])); c.set(Calendar.MONTH,Integer.parseInt(ds[1])-1); c.set(Calendar.DAY_OF_MONTH,Integer.parseInt(ds[2])); c.set(Calendar.HOUR_OF_DAY,Integer.parseInt(ts[0])); c.set(Calendar.MINUTE,Integer.parseInt(ts[1])); c.set(Calendar.SECOND,0); c.set(Calendar.MILLISECOND,0); return c.getTimeInMillis();
        }
    }
}
