MINHA GARAGEM 25 - CAMERA/GALERIA CORRIGIDAS

Correcoes:
- Removida a verificacao resolveActivity que estava acusando falsamente que nao havia camera.
- A abertura da camera agora acontece depois da permissao, sem atraso fixo.
- Botao superior da camera usa a mesma abertura nativa.
- Galeria continua usando seletor nativo do Android.
