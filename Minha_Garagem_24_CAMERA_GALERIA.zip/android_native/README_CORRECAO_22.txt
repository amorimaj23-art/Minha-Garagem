MINHA GARAGEM - CORRECAO 22

Correcoes aplicadas para compilacao do APK:
1. Corrigido o acesso as configuracoes de alarmes exatos no MainActivity.java.
2. Corrigida a conversao de long para int no AlarmReceiver.java.

Este ZIP e o projeto Android corrigido. Ele ainda precisa ser compilado pelo GitHub Actions para gerar o APK.
