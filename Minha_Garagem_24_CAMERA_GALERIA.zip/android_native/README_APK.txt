MINHA GARAGEM 20.0 - GERADOR DE APK

Este projeto inclui o alarme nativo Android. O arquivo .github/workflows/build-apk.yml gera automaticamente o APK de debug.

OPÇÃO MAIS FÁCIL (GitHub):
1. Crie um repositório novo no GitHub.
2. Envie todos os arquivos desta pasta android_native para a raiz do repositório.
3. Abra a aba Actions.
4. Selecione "Gerar APK Minha Garagem".
5. Toque em "Run workflow".
6. Quando terminar, abra a execução e baixe o artefato "Minha-Garagem-20-APK".
7. Dentro do ZIP estará o app-debug.apk para instalar no Motorola.

O APK usa as permissões de notificações e alarmes exatos do Android. Ao instalar, permita as notificações e, quando solicitado pelo Android, "Alarmes e lembretes".
