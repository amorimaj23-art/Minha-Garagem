MINHA GARAGEM 20.0 — ANDROID COM ALARMES NATIVOS

Esta pasta e um projeto Android Studio. A versao Android registra os alarmes no AlarmManager do Android, para que a notificacao possa chegar mesmo com o aplicativo fechado e a tela bloqueada.

Permissoes: notificacoes (Android 13+), Alarmes e lembretes (Android 12+), reinicio do aparelho para reprogramar alarmes.

IMPORTANTE: este ambiente nao possui Android SDK/Gradle para gerar um APK diretamente. Abra o projeto no Android Studio, aguarde a sincronizacao e gere o APK.

O site Minha Garagem v19.1 foi mantido dentro de app/src/main/assets/index.html; fotos e dados locais continuam sendo tratados pelo WebView.
