package com.minhagaragem.app;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Notification;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class AlarmReceiver extends BroadcastReceiver {
    public static final String ACTION_ALARM="com.minhagaragem.app.ALARM";
    private static final String CHANNEL="maintenance_alarms";
    @Override public void onReceive(Context c,Intent in){
        String id=in.getStringExtra("id"); String msg=in.getStringExtra("message"); if(msg==null||msg.isEmpty()) msg="Manutenção/alerta da Minha Garagem";
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26){ NotificationChannel ch=new NotificationChannel(CHANNEL,"Alarmes da Minha Garagem",NotificationManager.IMPORTANCE_HIGH); ch.setDescription("Alertas de manutenção e cuidados do veículo"); ch.enableVibration(true); ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC); nm.createNotificationChannel(ch); }
        Intent open=new Intent(c,MainActivity.class); open.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi=PendingIntent.getActivity(c,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,CHANNEL):new Notification.Builder(c).setPriority(Notification.PRIORITY_MAX);
        b.setSmallIcon(com.minhagaragem.app.R.drawable.icon_192).setContentTitle("🚗 Minha Garagem").setContentText(msg).setStyle(new Notification.BigTextStyle().bigText(msg)).setAutoCancel(true).setContentIntent(pi).setDefaults(Notification.DEFAULT_ALL).setCategory(Notification.CATEGORY_ALARM).setVisibility(Notification.VISIBILITY_PUBLIC);
        int nid;
        try {
            nid = (int)(Math.abs(Long.parseLong(id) % Integer.MAX_VALUE));
        } catch(Exception e) {
            nid = (id == null)
                    ? (int)(System.currentTimeMillis() % Integer.MAX_VALUE)
                    : id.hashCode();
        }
        nm.notify(nid,b.build()); if(id!=null) AlarmStore.remove(c,id);
    }
}
