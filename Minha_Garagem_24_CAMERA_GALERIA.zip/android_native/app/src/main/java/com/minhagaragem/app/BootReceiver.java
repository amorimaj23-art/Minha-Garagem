package com.minhagaragem.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import java.util.Map;

public class BootReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c,Intent in){
  AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
  if(Build.VERSION.SDK_INT>=31 && !am.canScheduleExactAlarms()) return;
  for(Map.Entry<String,?> e:AlarmStore.all(c).entrySet()){
   String[] p=String.valueOf(e.getValue()).split("\\|",3); if(p.length<3) continue;
   try{
    String[] d=p[0].split("-"); String[] t=p[1].split(":"); java.util.Calendar cal=java.util.Calendar.getInstance(); cal.set(Integer.parseInt(d[0]),Integer.parseInt(d[1])-1,Integer.parseInt(d[2]),Integer.parseInt(t[0]),Integer.parseInt(t[1]),0); cal.set(java.util.Calendar.MILLISECOND,0); long when=cal.getTimeInMillis(); if(when<=System.currentTimeMillis()) continue;
    Intent ai=new Intent(c,AlarmReceiver.class).setAction(AlarmReceiver.ACTION_ALARM).putExtra("id",e.getKey()).putExtra("message",p[2]);
    int code; try{code=(int)(Long.parseLong(e.getKey())%1000000000L);}catch(Exception x){code=e.getKey().hashCode();}
    PendingIntent pi=PendingIntent.getBroadcast(c,code,ai,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    PendingIntent show=PendingIntent.getActivity(c,0,new Intent(c,MainActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    am.setAlarmClock(new AlarmManager.AlarmClockInfo(when,show),pi);
   }catch(Exception ignored){}
  }
 }
}
