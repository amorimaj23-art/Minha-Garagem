package com.minhagaragem.app;
import android.content.Context;
import android.content.SharedPreferences;
import java.util.Map;

public class AlarmStore {
    private static final String PREF="native_alarms";
    public static void put(Context c,String id,String date,String time,String msg){c.getSharedPreferences(PREF,0).edit().putString(id,date+"|"+time+"|"+msg.replace("|"," ")).apply();}
    public static void remove(Context c,String id){c.getSharedPreferences(PREF,0).edit().remove(id).apply();}
    public static Map<String,?> all(Context c){return c.getSharedPreferences(PREF,0).getAll();}
}
